#relevant channel - ID 22
