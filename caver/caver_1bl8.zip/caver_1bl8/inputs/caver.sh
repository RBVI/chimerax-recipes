java -Xmx1200m -jar ../../../../caver/caver.jar -home ../../ -pdb ./ -conf ./config.txt -out ./out
